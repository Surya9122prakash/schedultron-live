import { Calendar, DayView, WeekView, MonthView } from "schedultron";
import moment, { Moment } from "moment-timezone";
import { useState } from "react";

const App = () => {

  const [selectedDate, setSelectedDate] = useState<Moment>(moment());
  const [view, setView] = useState<"calendar" | "day" | "week" | "month">("calendar");
  const [calendarTheme, setCalendarTheme] = useState<any>("emerald_forest");
  const [conflictTheme, setConflictTheme] = useState<any>("amber_warning");

  const [events, setEvents] = useState([
    {
      id: "1",
      title: "Morning Meeting",
      start: moment().hour(9).minute(0).toISOString(),
      end: moment().hour(10).minute(0).toISOString(),
      color: "#4CAF50",
      status: "confirmed"
    },
    {
      id: "2",
      title: "Lunch Break",
      start: moment().hour(13).minute(0).toISOString(),
      end: moment().hour(14).minute(0).toISOString(),
      color: "#FF9800",
      status: "scheduled"
    }
  ]);

  const handleAddEvent = (event: any) => setEvents([...events, event]);

  const handleEditEvent = (updated: any) =>
    setEvents(events.map(e => e.id === updated.id ? updated : e));

  const handleDeleteEvent = (id: string) =>
    setEvents(events.filter(e => e.id !== id));

  const testPlugins = [
    {
      name: "ConflictDetectionPlugin",
      hooks: {
        validateSave: (event: any) => {
          const newStart = moment(event.start);
          const newEnd = moment(event.end);

          const hasConflict = events.some((existingEvent: any) => {
            if (existingEvent.id === event.id) return false;

            const existingStart = moment(existingEvent.start);
            const existingEnd = moment(existingEvent.end);

            return newStart.isBefore(existingEnd) && newEnd.isAfter(existingStart);
          });

          if (hasConflict) {
            return "This event conflicts with an existing schedule. Please choose a different time.";
          }
          return null;
        }
      }
    },
    {
      name: "ShortEventValidator",
      hooks: {
        validateSave: (event: any) => {
          const duration = moment(event.end).diff(moment(event.start), "minutes");
          if (duration < 30) {
            return "Event duration must be at least 30 minutes!";
          }
          return null;
        }
      }
    },
    {
      name: "StatusIconPlugin",
      hooks: {
        onEventRender: (event: any, element: HTMLElement) => {
          if (event.status === "confirmed") {
            element.style.border = "4px solid gold";
          }
        }
      }
    }
  ];

  const commonProps = {
    timezone: "America/New_York",
    timezoneLabelInclude: true,
    selectedDate,
    onDateChange: setSelectedDate,
    events,
    onAddEvent: handleAddEvent,
    onEditEvent: handleEditEvent,
    onDeleteEvent: handleDeleteEvent,
    dateFormat: "DD/MM/YYYY",
    timeFormat: "hh:mm A",
    calendarThemeVariant: calendarTheme,
    conflictThemeVariant: conflictTheme,
    plugins: testPlugins
  };

  return (
    <div style={{ height: "100vh", padding: 20 }}>

      {/* View Switch */}
      <div style={{ display: "flex", gap: 10, marginBottom: 20 }}>
        <button onClick={() => setView("calendar")}>Calendar</button>
        <button onClick={() => setView("day")}>Day</button>
        <button onClick={() => setView("week")}>Week</button>
        <button onClick={() => setView("month")}>Month</button>
      </div>

      {/* Theme Selectors */}
      <div style={{ display: "flex", gap: 20, marginBottom: 20 }}>
        <div>
          <label style={{ marginRight: 10 }}>Calendar Theme:</label>
          <select value={calendarTheme} onChange={(e) => setCalendarTheme(e.target.value)}>
            <option value="classic_light">Classic Light</option>
            <option value="dark_night">Dark Night</option>
            <option value="slate_modern">Slate Modern</option>
            <option value="emerald_forest">Emerald Forest</option>
            <option value="ocean_breeze">Ocean Breeze</option>
            <option value="midnight_purple">Midnight Purple</option>
            <option value="amber_gold">Amber Gold</option>
            <option value="rose_petal">Rose Petal</option>
            <option value="minimal_mono">Minimal Mono</option>
            <option value="cyber_punk">Cyber Punk</option>
          </select>
        </div>

        <div>
          <label style={{ marginRight: 10 }}>Conflict Theme:</label>
          <select value={conflictTheme} onChange={(e) => setConflictTheme(e.target.value)}>
            <option value="classic_red">Classic Red</option>
            <option value="amber_warning">Amber Warning</option>
            <option value="indigo_modern">Indigo Modern</option>
            <option value="emerald_soft">Emerald Soft</option>
            <option value="dark_noir">Dark Noir</option>
            <option value="rose_elegant">Rose Elegant</option>
            <option value="glassmorphism">Glassmorphism</option>
            <option value="cyberpunk">Cyberpunk</option>
            <option value="minimalist">Minimalist</option>
            <option value="high_visibility">High Visibility</option>
          </select>
        </div>
      </div>

      {view === "calendar" && (
        <Calendar {...commonProps} />
      )}

      {view === "day" && (
        <DayView
          {...commonProps}
          slotInterval={60}
          showTimeSlots={true}
          showEmptyState={true}
          emptyStateContent="No events for this date"
          emptyStateContentPopup="No Scheduled Events"
          navigateToFirstEvent={true}
        />
      )}

      {view === "week" && (
        <WeekView {...commonProps} />
      )}

      {view === "month" && (
        <MonthView {...commonProps} />
      )}

    </div>
  );
};

export default App;